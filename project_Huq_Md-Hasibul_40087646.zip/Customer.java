public class Customer {
	public String name;
	public int amount;
	
	Customer(String name, int amount){
		this.name = name;
		this.amount = amount;
	}
}


import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BankThread extends Thread {
	Money money = new Money();
	String bankName;
	List<String> bankNames = new ArrayList<>(money.bank.keySet());
	public BankThread(String threadName){
		super(threadName);
		bankName = threadName;
    }
	
	@Override
    public void run() {
        synchronized (this) {
            try {
                sleep(new Random().nextInt(100) + 1);
            } catch (InterruptedException e) { }
           
            while(money.bank.get(bankName)>0 ) {
            	if(money.request.get(bankName)!=null && !money.request.get(bankName).isEmpty()) {
            		List<String> customerNames = new ArrayList<>(money.customer.keySet());
	            	if(money.bank.get(bankName) - money.request.get(bankName).get(0).amount >= 0) {
	            		money.bankHistory.put(bankName, money.bank.get(bankName)- money.request.get(bankName).get(0).amount);
	            		money.bankStatus(money.request.get(bankName).get(0).amount, bankName, "Accepted", money.request.get(bankName).get(0).name);
	            		money.request.get(bankName).remove(0);
	            	}else {
	            		money.bankStatus(money.request.get(bankName).get(0).amount, bankName, "Declined", money.request.get(bankName).get(0).name);
	            		money.request.get(bankName).remove(0);
	            	}
            	}
            }
           
        }
    }
}
